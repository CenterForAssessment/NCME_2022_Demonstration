Child_RMD
=========

This directory contains RMarkdown "child" scripts for the NCME 2022 Demonstration
session reports. These report sections and pieces can be used interchangeably across
templates to create different types of output, including working papers, `xaringan`
presentations or polished reports and websites using the `pagedown` and `bookdown`
packages.
