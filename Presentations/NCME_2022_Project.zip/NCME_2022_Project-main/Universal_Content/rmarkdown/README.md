Report Assets
=============

#  Purpose

This subdirectory contains assets ("universal" RMD files, css, js, pandoc, etc.
that can/should be used in all reports) necessary for the creation of the NCME
2022 Demonstration session reports. See the README.md files in each subdirectory
for more information.
