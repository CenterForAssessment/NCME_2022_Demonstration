# Universal_Content

R Markdown and other content related items for creation of reports and documentation
