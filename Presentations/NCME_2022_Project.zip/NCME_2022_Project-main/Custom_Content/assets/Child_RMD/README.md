Child_RMD
=========

This directory contains RMarkdown "child" scripts for the NCME 2022 Demonstration
session reports. These are report sections and pieces that are customized or
specific to a particular report (i.e., not interchangeable or universal). They
can still be used across different templates to create various output, including
working papers, `xaringan` presentations or polished reports and websites using
the `pagedown` and `bookdown` packages.
